﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class bankWithdrawal
    {
        public string bank_id { get; set; }
        public float withdrawal_amount { get; set; }
        public string withdrawal_date { get; set; }
        public string withdrawer { get; set; }
        public string withdrawal_reason { get; set; }
        public int withdrawal_type { get; set; }
    }
}