﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class treasuryBankTransfer
    {
        public string treasury_id { get; set; }
        public string bank_id { get; set; }
        public float amount { get; set; }
        public string trans_admin { get; set; }
        public string trans_date { get; set; }
        public string reason { get; set; }
        public string trans_type { get; set; }
    }
}