﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class costChanges
    {
        public string product_id { get; set; }
        public string invent_id { get; set; }
        public string old_purchase_price { get; set; }
        public string new_purchase_price { get; set; }
        public string old_sell_price { get; set; }
        public string new_sell_price { get; set; }
        public string change_date { get; set; }
    }
}