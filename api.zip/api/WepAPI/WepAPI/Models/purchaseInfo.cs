﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class purchaseInfo
    {
        public string inv_no { get; set; }
        public string supplier_id { get; set; }
        public string supplier_inv_no { get; set; }
        public string inventory_id { get; set; }
        public string quantity { get; set; }
        public string total_cost { get; set; }
        public string payment_type { get; set; }
        public string supplier_type { get; set; }
        public string due_date { get; set; }
        public string product_id { get; set; }
        public string product_quantity { get; set; }
        public string taxable { get; set; }
        public string product_unit_price { get; set; }
        public string product_total_cost { get; set; }
        public string invoice_date { get; set; }
        public string date1 { get; set; }
        public string date2 { get; set; }
        public string returned_quantity { get; set; }
        public string return_date { get; set; }
    }
}