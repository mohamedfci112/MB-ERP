﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class treasuryDeposit
    {
        public string treasury_id { get; set; }
        public float deposit_amount { get; set; }
        public string deposit_date { get; set; }
        public string depositor { get; set; }
        public string deposit_reason { get; set; }
        public int deposit_type { get; set; }
    }
}