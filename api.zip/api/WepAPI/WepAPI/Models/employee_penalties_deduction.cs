﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class employee_penalties_deduction
    {
        public string emp_id { get; set; }
        public float amount { get; set; }
        public string admin_person { get; set; }
        public string deduct_date { get; set; }
        public string due_date { get; set; }
        public string reason { get; set; }
    }
}