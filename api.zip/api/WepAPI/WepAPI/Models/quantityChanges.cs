﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class quantityChanges
    {
        public string product_id { get; set; }
        public string invent_id { get; set; }
        public string old_product_quantity { get; set; }
        public string new_product_quantity { get; set; }
        public string change_date { get; set; }
    }
}