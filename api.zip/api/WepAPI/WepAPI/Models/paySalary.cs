﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class paySalary
    {
        public string ezn_no { get; set; }
        public string emp_id { get; set; }
        public string ezn_date { get; set; }
        public string due_date { get; set; }
        public string salary { get; set; }
        public string advances { get; set; }
        public string salary_after { get; set; }
        public string notes { get; set; }
        public string treasury_id { get; set; }
    }
}