﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class inventoryTalf
    {
        public string product_id { get; set; }
        public string product_talf_quantity { get; set; }
        public string talf_date { get; set; }
        public string talf_admin { get; set; }
        public string talf_reason { get; set; }
        public string invent_id { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
    }
}