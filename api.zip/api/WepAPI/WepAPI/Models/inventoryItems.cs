﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class inventoryItems
    {
        public string product_id { get; set; }
        public string invent_id { get; set; }
        public string product_quantity { get; set; }
        public string purchase_price { get; set; }
        public string sell_price { get; set; }
    }
}