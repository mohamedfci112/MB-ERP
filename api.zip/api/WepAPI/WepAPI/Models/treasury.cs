﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class treasury
    {
        public string treasury_id { get; set; }
        public string treasury_name { get; set; }
    }
}