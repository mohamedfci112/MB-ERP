﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class bank
    {
        public string bank_id { get; set; }
        public string bank_name { get; set; }
    }
}