﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class supplier
    {
        public string sup_no { get; set; }
        public string sup_name { get; set; }
        public string admin_name { get; set; }
        public string sup_phone { get; set; }
        public string sup_tax { get; set; }
        public string sup_address { get; set; }
        public string notes { get; set; }
    }
}