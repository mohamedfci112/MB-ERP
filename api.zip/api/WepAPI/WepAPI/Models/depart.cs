﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class depart
    {
        public string depart_id { get; set; }
        public string depart_name { get; set; }
    }
}