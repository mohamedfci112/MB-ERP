﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class treasuryTransfer
    {
        public string treasury_from_id { get; set; }
        public string treasury_to_id { get; set; }
        public float amount { get; set; }
        public string trans_admin { get; set; }
        public string trans_date { get; set; }
        public string reason { get; set; }
    }
}