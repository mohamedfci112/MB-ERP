﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class unit
    {
        public string unit_id { get; set; }
        public string unit_name { get; set; }
    }
}