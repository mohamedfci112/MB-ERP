﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class expenses
    {
        public string exp_id { get; set; }
        public string exp_name { get; set; }
    }
}