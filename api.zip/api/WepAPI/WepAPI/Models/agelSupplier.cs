﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class agelSupplier
    {
        public string sup_no { get; set; }
        public string amount { get; set; }
        public string inv_no { get; set; }
        public string inv_date { get; set; }
        public string due_date { get; set; }
    }
}