﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class expensesDetails
    {
        public string exp_id { get; set; }
        public string amount { get; set; }
        public string treasury_id { get; set; }
        public string exp_date { get; set; }
        public string notes { get; set; }
    }
}