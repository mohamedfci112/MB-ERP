﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class advanceInfo
    {
        public string adv_id { get; set; }
        public string emp_id { get; set; }
        public string person_name { get; set; }
        public string due_date { get; set; }
        public string adv_amount { get; set; }
        public string creditor { get; set; }
        public string notes { get; set; }
        public string type { get; set; }
        public string treasury_id { get; set; }
        public string dateFrom { get; set; }
        public string dateTo { get; set; }
    }
}