﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class inventoryTransfers
    {
        public string product_id { get; set; }
        public string invent_from_id { get; set; }
        public string invent_to_id { get; set; }
        public string product_quantity { get; set; }
        public string purchase_price { get; set; }
        public string sell_price { get; set; }
        public string trans_date { get; set; }
        public string trans_admin { get; set; }
        public string trans_reason { get; set; }
        public string date1 { get; set; }
        public string date2 { get; set; }
    }
}