﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class customer
    {
        public string cust_no { get; set; }
        public string cust_name { get; set; }
        public string admin_name { get; set; }
        public string cust_phone { get; set; }
        public string cust_address { get; set; }
        public string notes { get; set; }
    }
}