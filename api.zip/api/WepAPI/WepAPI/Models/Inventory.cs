﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class Inventory
    {
        public string invent_id { get; set; }
        public string invent_name { get; set; }
        public string notes { get; set; }

    }
}