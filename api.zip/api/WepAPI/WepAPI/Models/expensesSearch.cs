﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class expensesSearch
    {
        public string exp_from { get; set; }
        public string exp_to { get; set; }
    }
}