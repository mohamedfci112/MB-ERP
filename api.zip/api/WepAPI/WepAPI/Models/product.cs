﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WepAPI.Models
{
    public class product
    {
        public string product_id { get; set; }
        public string product_name { get; set; }
        public string group_id { get; set; }
        public string unit_id { get; set; }
        public string depart_id { get; set; }
        public float product_limit { get; set; }
        public string part_no { get; set; }
        public float purchase_price { get; set; }
        public float sell_price { get; set; }
        public string product_description { get; set; }
        public string notes { get; set; }
        public int taxable { get; set; }
        public float taxes { get; set; }
        public int original { get; set; }
        public int coppy { get; set; }
        public int highcoppy { get; set; }
        public int compatable { get; set; }
        public string invent_id { get; set; }
    }
}