﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class PurchasesController : ApiController
    {

        [Route("api/Purchases/GetProductSearch")]
        [HttpPost]
        public HttpResponseMessage GetProductSearch(inventoryItems inv)
        {
            string query = @"select DISTINCT p.product_id, p.product_name from dbo.products p, inventory_items i where p.product_id=i.product_id and p.product_id='"+inv.product_id+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Purchases/getLastId")]
        [HttpGet]
        public HttpResponseMessage getLastId()
        {
            string query = @"select MAX(inv_no + 1) as lastId from dbo.purchasing_invoice";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        //add purchase fatora
        public string Post(purchaseInfo p)
        {
            try
            {
                string query = @"insert into dbo.purchasing_invoice(inv_no, supplier_id, supplier_inv_no,inventory_id,quantity,total_cost,payment_type,supplier_type, due_date, product_id, product_quantity, taxable, product_unit_price, product_total_cost,invoice_date) values(N'" + p.inv_no + "',N'" + p.supplier_id + "',N'" + p.supplier_inv_no + "',N'" + p.inventory_id + "',N'" + p.quantity + "',N'" + p.total_cost + "',N'" + p.payment_type + "',N'" + p.supplier_type + "',N'" + p.due_date + "',N'" + p.product_id + "',N'" + p.product_quantity + "',N'" + p.taxable + "',N'" + p.product_unit_price + "',N'" + p.product_total_cost + "',N'"+p.invoice_date+"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }


        [Route("api/Purchases/getPurchasingReport")]
        [HttpPost]
        public HttpResponseMessage getPurchasingReport(purchaseInfo p)
        {
            string query = @"select pr.inv_no, s.sup_name, p.product_name, pr.invoice_date, pr.product_quantity, pr.product_unit_price, pr.product_total_cost from dbo.products p, dbo.suppliers s, dbo.purchasing_invoice pr where p.product_id = pr.product_id and s.sup_no = pr.supplier_id and CAST(pr.invoice_date as date) between '"+p.date1+"' and '"+p.date2+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Purchases/getPurchasingSummeryReport")]
        [HttpPost]
        public HttpResponseMessage getPurchasingSummeryReport(purchaseInfo p)
        {
            string query = @"select DISTINCT pr.inv_no, pr.total_cost, s.sup_name, pr.invoice_date, CAST(pr.taxable as float) as taxable from dbo.suppliers s, dbo.purchasing_invoice pr where s.sup_no = pr.supplier_id and CAST(pr.invoice_date as date) between '" + p.date1 + "' and '" + p.date2 + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Purchases/GetAllPurchaseSearch")]
        [HttpPost]
        public HttpResponseMessage GetAllPurchaseSearch(purchaseInfo p)
        {
            string query = @"select * from dbo.purchasing_invoice where returned='0' and inv_no = N'" + p.inv_no + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Purchases/GetPurchasesSearch")]
        [HttpPost]
        public HttpResponseMessage GetPurchasesSearch(purchaseInfo p)
        {
            string query = @"select pr.*, p.product_name from dbo.products p, dbo.purchasing_invoice pr where p.product_id = pr.product_id and (pr.returned='0' or pr.product_quantity <> pr.returned_quantity) and pr.inv_no='" + p.inv_no + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Purchases/insertReturnedPurchasesAll")]
        [HttpPut]
        public HttpResponseMessage insertReturnedPurchasesAll(purchaseInfo p)
        {
            try
            {
                string query = @"update dbo.purchasing_invoice set returned=1, returned_quantity=N'"+p.returned_quantity+"', return_date=N'"+p.return_date+"' where inv_no=N'"+p.inv_no+"' and product_id=N'"+p.product_id+"'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

    }
}
