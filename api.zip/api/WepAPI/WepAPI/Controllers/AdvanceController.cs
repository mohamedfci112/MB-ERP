﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class AdvanceController : ApiController
    {
        //add advance
        public string Post(advanceInfo ai)
        {
            try
            {
                string query = @"insert into dbo.advance_info(adv_id, emp_id, person_name,due_date,adv_amount,creditor,notes,type, treasury_id) values(N'" + ai.adv_id + "',N'" + ai.emp_id + "',N'" + ai.person_name + "',N'"+ai.due_date+"',N'"+ai.adv_amount+"',N'"+ai.creditor+"',N'"+ai.notes+"',N'"+ai.type+"',N'"+ai.treasury_id+"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        [Route("api/Advance/GetLastID")]
        [HttpGet]
        public HttpResponseMessage GetLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.advance_info')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
