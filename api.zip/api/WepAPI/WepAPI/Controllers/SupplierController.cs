﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class SupplierController : ApiController
    {
        /////////////////////////////  supplier api  ////////////////////////////////////////////////////////////////


        //insert supplier
        public string Post(supplier sup)
        {
            try
            {
                string query = @"insert into dbo.suppliers(sup_no, sup_name, admin_name, sup_phone, sup_tax, sup_address, notes) values(N'" + sup.sup_no + "',N'" + sup.sup_name + "',N'" + sup.admin_name + "',N'" + sup.sup_phone + "',N'"+sup.sup_tax+"',N'" + sup.sup_address + "',N'" + sup.notes + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //edit supplier
        public string PUT(supplier sup)
        {
            try
            {
                string query = @"update dbo.suppliers set sup_name=N'" + sup.sup_name + "',admin_name=N'" + sup.admin_name + "', sup_phone=N'" + sup.sup_phone + "', sup_tax=N'"+sup.sup_tax+"', sup_address=N'" + sup.sup_address + "', notes=N'" + sup.notes + "' where sup_no='" + sup.sup_no + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete treasury
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.suppliers where sup_no='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all treasury
        [Route("api/Supplier/getAllSuppliers")]
        [HttpGet]
        public HttpResponseMessage getAllSuppliers()
        {
            string query = @"select * from dbo.suppliers";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetBankLastID
        [Route("api/Supplier/GetSupplierLastID")]
        [HttpGet]
        public HttpResponseMessage GetSupplierLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.suppliers')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetAllSuppliersSearch
        [Route("api/Supplier/GetAllSuppliersSearch")]
        [HttpPost]
        public HttpResponseMessage GetAllSuppliersSearch(supplier sup)
        {
            string query = @"select * from dbo.suppliers where sup_name like N'%" + sup.sup_name + "%'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Supplier/GetSuppliersSearch")]
        [HttpPost]
        public HttpResponseMessage GetSuppliersSearch(supplier sup)
        {
            string query = @"select * from dbo.suppliers where sup_no = '" + sup.sup_no + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
