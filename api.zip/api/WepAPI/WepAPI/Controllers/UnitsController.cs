﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class UnitsController : ApiController
    {
        //add units
        public string Post(unit u)
        {
            try
            {
                string query = @"insert into dbo.units(unit_id, unit_name) values(N'" + u.unit_id + "',N'" + u.unit_name + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete units
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.units where unit_id='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all units
        [Route("api/Units/getAllUnits")]
        [HttpGet]
        public HttpResponseMessage getAllUnits()
        {
            string query = @"select * from dbo.units";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetUnitLastID
        [Route("api/Units/GetUnitLastID")]
        [HttpGet]
        public HttpResponseMessage GetUnitLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.units')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


    }
}
