﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        /////////////////////////////  employee api  ////////////////////////////////////////////////////////////////
        //insert employees
        public string Post(employee emp)
        {
            try
            {
                string query = @"insert into dbo.employee(emp_id, emp_name, emp_job, emp_salary, due_date, emp_national_id, phone) values(N'" + emp.emp_id + "',N'" + emp.emp_name + "',N'" + emp.emp_job + "',N'" + emp.emp_salary + "',N'" + emp.due_date + "',N'" + emp.emp_national_id + "',N'" + emp.phone + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete customers
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.employee where emp_id='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all employees
        [Route("api/Employee/getAllEmployees")]
        [HttpGet]
        public HttpResponseMessage getAllEmployees()
        {
            string query = @"select * from dbo.employee";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetCustomerLastID
        [Route("api/Employee/GetEmployeeLastID")]
        [HttpGet]
        public HttpResponseMessage GetEmployeeLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.employee')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
