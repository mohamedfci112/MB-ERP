﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class CustomerController : ApiController
    {
        /////////////////////////////  customer api  ////////////////////////////////////////////////////////////////


        //insert customers
        public string Post(customer cust)
        {
            try
            {
                string query = @"insert into dbo.customers(cust_no, cust_name, admin_name, cust_phone, cust_address, notes) values(N'" + cust.cust_no + "',N'" + cust.cust_name + "',N'" + cust.admin_name + "',N'" + cust.cust_phone + "',N'" + cust.cust_address + "',N'" + cust.notes + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //edit customers
        public string PUT(customer cust)
        {
            try
            {
                string query = @"update dbo.customers set cust_name=N'" + cust.cust_name + "',admin_name=N'" + cust.admin_name + "', cust_phone=N'" + cust.cust_phone + "', cust_address=N'" + cust.cust_address + "', notes=N'" + cust.notes + "' where cust_no='" + cust.cust_no + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete customers
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.customers where cust_no='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all customers
        [Route("api/Customer/getAllCustomers")]
        [HttpGet]
        public HttpResponseMessage getAllCustomers()
        {
            string query = @"select * from dbo.customers";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetCustomerLastID
        [Route("api/Customer/GetCustomerLastID")]
        [HttpGet]
        public HttpResponseMessage GetCustomerLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.customers')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetAllCustomersSearch
        [Route("api/Customer/GetAllCustomersSearch")]
        [HttpPost]
        public HttpResponseMessage GetAllCustomersSearch(customer cust)
        {
            string query = @"select * from dbo.customers where cust_name like N'%" + cust.cust_name + "%'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Customer/GetCustomerSearch")]
        [HttpPost]
        public HttpResponseMessage GetCustomerSearch(customer cust)
        {
            string query = @"select * from dbo.customers where cust_no = '" + cust.cust_no + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
    }
}
