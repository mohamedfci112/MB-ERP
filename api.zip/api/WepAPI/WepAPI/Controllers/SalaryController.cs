﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class SalaryController : ApiController
    {
        //add advance
        public string Post(paySalary ps)
        {
            try
            {
                string query = @"insert into dbo.pay_salary(ezn_no, emp_id, ezn_date,due_date,salary,advances,salary_after,notes, treasury_id) values(N'" + ps.ezn_no + "',N'" + ps.emp_id + "',N'" + ps.ezn_date + "',N'" + ps.due_date + "',N'" + ps.salary + "',N'" + ps.advances + "',N'" + ps.salary_after + "',N'" + ps.notes + "',N'" + ps.treasury_id + "')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }


        [Route("api/Salary/GetLastID")]
        [HttpGet]
        public HttpResponseMessage GetLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.pay_salary')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Salary/GetEmpAdvances")]
        [HttpPost]
        public HttpResponseMessage GetEmpAdvances(advanceInfo a)
        {
            string query = @"select SUM(a.adv_amount) as total_advances from dbo.employee e, dbo.advance_info a where e.emp_id=a.emp_id and e.emp_id='"+a.emp_id+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Salary/GetEmpPenalties")]
        [HttpPost]
        public HttpResponseMessage GetEmpPenalties(advanceInfo a)
        {
            string query = @"select SUM(ep.amount) as total_penalties from dbo.employee e, dbo.employee_penalties_deduction ep where e.emp_id=ep.emp_id and e.emp_id='"+a.emp_id+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Salary/GetEmpSalary")]
        [HttpPost]
        public HttpResponseMessage GetEmpSalary(advanceInfo a)
        {
            string query = @"select emp_salary from dbo.employee where emp_id='"+a.emp_id+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Salary/GetTotalEmpPenalties")]
        [HttpPost]
        public HttpResponseMessage GetTotalEmpPenalties(advanceInfo a)
        {
            string query = @"select * from dbo.employee_penalties_deduction where amount>0 and emp_id='" + a.emp_id + "' and deduct_date between '"+a.dateFrom+"' and '"+a.dateTo+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Salary/GetTotalEmpAdvances")]
        [HttpPost]
        public HttpResponseMessage GetTotalEmpAdvances(advanceInfo a)
        {
            string query = @"select * from dbo.advance_info where adv_amount>0 and emp_id='" + a.emp_id + "' and due_date between '" + a.dateFrom + "' and '" + a.dateTo + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
    }
}
