﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class EmployeepenaltiesdeductionController : ApiController
    {
        //insert employees penalties deduction
        public string Post(employee_penalties_deduction epd)
        {
            try
            {
                string query = @"insert into dbo.employee_penalties_deduction(emp_id, amount, admin_person, deduct_date, due_date, reason) values(N'" + epd.emp_id + "',N'" + epd.amount + "',N'" + epd.admin_person + "',N'" + epd.deduct_date + "',N'" + epd.due_date + "',N'" + epd.reason + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        // GetCustomerLastID
        [Route("api/Employeepenaltiesdeduction/GetLastID")]
        [HttpGet]
        public HttpResponseMessage GetLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.employee_penalties_deduction')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
