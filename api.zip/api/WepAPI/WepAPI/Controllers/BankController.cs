﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class BankController : ApiController
    {

        /////////////////////////////  bank api  ////////////////////////////////////////////////////////////////


        //insert bank
        [Route("api/Bank/insertBank")]
        [HttpPost]
        public string insertBank(bank ba)
        {
            try
            {
                string query = @"insert into dbo.banks(bank_id, bank_name) values(N'" + ba.bank_id + "',N'" + ba.bank_name + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //edit treasury
        [Route("api/Bank/editBank")]
        [HttpPut]
        public string editBank(bank ba)
        {
            try
            {
                string query = @"update dbo.banks set bank_name=N'" + ba.bank_name + "' where bank_id='" + ba.bank_id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete treasury
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.banks where bank_id='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all treasury
        [Route("api/Bank/getAllBanks")]
        [HttpGet]
        public HttpResponseMessage getAllBanks()
        {
            string query = @"select * from dbo.banks";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetBankLastID
        [Route("api/Bank/GetBankLastID")]
        [HttpGet]
        public HttpResponseMessage GetBankLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.banks')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        // bank deposit
        [Route("api/Bank/bankDeposit")]
        [HttpPost]
        public string bankDeposit(bankDeposit bd)
        {
            try
            {
                string query = @"insert into dbo.bank_deposit(bank_id, deposit_amount, deposit_date, depositor, deposit_reason, deposit_type) values(N'" + bd.bank_id + "',N'" + bd.deposit_amount + "',N'" + bd.deposit_date + "',N'" + bd.depositor + "',N'" + bd.deposit_reason + "',N'" + bd.deposit_type + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive total balance in bank
        [Route("api/Bank/getTotalBalanceBank")]
        [HttpPost]
        public HttpResponseMessage getTotalBalanceBank(bankDeposit bd)
        {
            string query = @"select SUM(deposit_amount) as total from dbo.bank_deposit where bank_id='" + bd.bank_id + @"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        // bank withdrawal
        [Route("api/Bank/bankWithdrawal")]
        [HttpPost]
        public string bankWithdrawal(bankWithdrawal bw)
        {
            try
            {
                string query = @"insert into dbo.bank_withdrawal(bank_id, withdrawal_amount, withdrawal_date, withdrawer, withdrawal_reason, withdrawal_type) values(N'" + bw.bank_id + "',N'" + bw.withdrawal_amount + "',N'" + bw.withdrawal_date + "',N'" + bw.withdrawer + "',N'" + bw.withdrawal_reason + "',N'" + bw.withdrawal_type + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive last 3 deposits in Bank
        [Route("api/Bank/getLastDepositsBank")]
        [HttpPost]
        public HttpResponseMessage getLastDepositsBank(bank td)
        {
            string query = @"select TOP 5 * from dbo.bank_deposit where deposit_type = '1' and bank_id='" + td.bank_id + "' order by id desc";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
