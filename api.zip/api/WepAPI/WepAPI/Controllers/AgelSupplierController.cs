﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class AgelSupplierController : ApiController
    {
        //add 
        public string Post(agelSupplier a)
        {
            try
            {
                string query = @"insert into dbo.agel_suppliers_acc(sup_no, amount, inv_no,inv_date,due_date) values(N'" + a.sup_no + "',N'" + a.amount + "',N'" + a.inv_no + "',N'" + a.inv_date + "',N'" + a.due_date + "')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }
    }
}
