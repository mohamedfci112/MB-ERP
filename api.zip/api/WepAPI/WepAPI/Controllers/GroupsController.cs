﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;
namespace WepAPI.Controllers
{
    public class GroupsController : ApiController
    {
        //add units
        public string Post(groups g)
        {
            try
            {
                string query = @"insert into dbo.groups(group_id, group_name) values(N'" + g.group_id + "',N'" + g.group_name + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete units
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.groups where group_id='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all units
        [Route("api/Groups/getAllGroups")]
        [HttpGet]
        public HttpResponseMessage getAllGroups()
        {
            string query = @"select * from dbo.groups";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetUnitLastID
        [Route("api/Groups/GetGroupLastID")]
        [HttpGet]
        public HttpResponseMessage GetGroupLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.groups')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
