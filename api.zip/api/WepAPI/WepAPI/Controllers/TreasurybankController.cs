﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class TreasurybankController : ApiController
    {

        /////////////////////////////  treasury api  ////////////////////////////////////////////////////////////////
        //insert treasury
        [Route("api/Treasurybank/insertTreasury")]
        [HttpPost]
        public string insertTreasury(treasury tr)
        {
            try
            {
                string query = @"insert into dbo.treasury(treasury_id, treasury_name) values(N'" + tr.treasury_id + "',N'" + tr.treasury_name + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //edit treasury
        [Route("api/Treasurybank/editTreasury")]
        [HttpPut]
        public string editTreasury(treasury tr)
        {
            try
            {
                string query = @"update dbo.treasury set treasury_name=N'" + tr.treasury_name + "' where treasury_id='" + tr.treasury_id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete treasury
        
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.treasury where treasury_id='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all treasury
        [Route("api/Treasurybank/getAllTreasury")]
        [HttpGet]
        public HttpResponseMessage getAllTreasury()
        {
            string query = @"select * from dbo.treasury";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        //retrive main treasury
        [Route("api/Treasurybank/getMainTreasury")]
        [HttpGet]
        public HttpResponseMessage getMainTreasury()
        {
            string query = @"select * from dbo.treasury where main= '1'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        //GetTreasuryLastID
        [Route("api/Treasurybank/GetTreasuryLastID")]
        [HttpGet]
        public HttpResponseMessage GetTreasuryLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.treasury')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }



        // treasury deposit
        //insert treasury
        [Route("api/Treasurybank/treasuryDeposit")]
        [HttpPost]
        public string treasuryDeposit(treasuryDeposit td)
        {
            try
            {
                string query = @"insert into dbo.treasury_deposit(treasury_id, deposit_amount, deposit_date, depositor, deposit_reason, deposit_type) values(N'" + td.treasury_id + "',N'" + td.deposit_amount + "',N'" + td.deposit_date + "',N'" + td.depositor + "',N'" + td.deposit_reason + "',N'" + td.deposit_type + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive total balance in treasury
        [Route("api/Treasurybank/getTotalBalanceTreasury")]
        [HttpPost]
        public HttpResponseMessage getTotalBalanceTreasury(treasuryDeposit td)
        {
            string query = @"select SUM(deposit_amount) as total from dbo.treasury_deposit where treasury_id='"+ td.treasury_id + @"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        //retrive total balance in main treasury
        [Route("api/Treasurybank/getTotalBalanceMainTreasury")]
        [HttpGet]
        public HttpResponseMessage getTotalBalanceMainTreasury(treasuryDeposit td)
        {
            string query = @"select SUM(td.deposit_amount) as total from dbo.treasury_deposit td, dbo.treasury t where td.treasury_id=t.treasury_id and t.main='1'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        // treasury withdrawal
        [Route("api/Treasurybank/treasuryWithdrawal")]
        [HttpPost]
        public string treasuryWithdrawal(treasuryWithdrawal tw)
        {
            try
            {
                string query = @"insert into dbo.treasury_withdrawal(treasury_id, withdrawal_amount, withdrawal_date, withdrawer, withdrawal_reason, withdrawal_type) values(N'" + tw.treasury_id + "',N'" + tw.withdrawal_amount + "',N'" + tw.withdrawal_date + "',N'" + tw.withdrawer + "',N'" + tw.withdrawal_reason + "',N'" + tw.withdrawal_type + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        // treasury transfers
        [Route("api/Treasurybank/treasuryTransfer")]
        [HttpPost]
        public string treasuryTransfer(treasuryTransfer t)
        {
            try
            {
                string query = @"insert into dbo.treasury_transfers(treasury_from_id, treasury_to_id, amount, trans_admin, trans_date, reason) values(N'" + t.treasury_from_id + "',N'" + t.treasury_to_id + "',N'" + t.amount + "',N'" + t.trans_admin + "',N'" + t.trans_date + "',N'" + t.reason + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        // treasury bank transfers
        [Route("api/Treasurybank/treasuryBankTransfer")]
        [HttpPost]
        public string treasuryBankTransfer(treasuryBankTransfer t)
        {
            try
            {
                string query = @"insert into dbo.treasury_bank_transfers(treasury_id, bank_id, amount, trans_admin, trans_date, reason, trans_type) values(N'" + t.treasury_id + "',N'" + t.bank_id + "',N'" + t.amount + "',N'" + t.trans_admin + "',N'" + t.trans_date + "',N'" + t.reason + "',N'" + t.trans_type + "')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }


        //retrive last 3 deposits in treasury
        [Route("api/Treasurybank/getLastDepositsTreasury")]
        [HttpPost]
        public HttpResponseMessage getLastDepositsTreasury(treasuryDeposit td)
        {
            string query = @"select TOP 5 * from dbo.treasury_deposit where deposit_type = '1' and treasury_id='" + td.treasury_id + "' order by id desc";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }



    }
}
