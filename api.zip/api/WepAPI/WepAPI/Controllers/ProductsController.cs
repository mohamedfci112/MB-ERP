﻿using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class ProductsController : ApiController
    {
        //add Products
        public string Post(product p)
        {
            try
            {
                string query = @"insert into dbo.products(product_id, product_name, group_id, unit_id, depart_id, product_limit, part_no, purchase_price, sell_price, product_description, notes, taxable, taxes, original, compatable, highcoppy, coppy, invent_id) values(N'" + p.product_id + "',N'" + p.product_name + "',N'" + p.group_id + "',N'" + p.unit_id + "',N'" + p.depart_id + "',N'" + p.product_limit + "',N'" + p.part_no + "',N'" + p.purchase_price + "',N'" + p.sell_price + "',N'" + p.product_description + "',N'" + p.notes + "', N'" + p.taxable + "',N'" + p.taxes + "',N'" + p.original + "',N'"+p.compatable+"',N'"+p.highcoppy+"',N'" + p.coppy + "',N'" + p.invent_id + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all products
        [Route("api/Products/getAllProducts")]
        [HttpGet]
        public HttpResponseMessage getAllProducts()
        {
            string query = @"select * from dbo.products";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetProductLastID
        [Route("api/Products/GetProductLastID")]
        [HttpGet]
        public HttpResponseMessage GetProductLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.products')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        //retrive all products limits
        [Route("api/Products/getAllProductsLimits")]
        [HttpGet]
        public HttpResponseMessage getAllProductsLimits()
        {
            string query = @"select p.product_name as product_name, i.product_quantity as product_quantity, p.product_limit as product_limit from dbo.products p, dbo.inventory_items i where p.product_id=i.product_id and i.product_quantity < p.product_limit";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        //retrive all products details
        [Route("api/Products/getAllProductsDetails")]
        [HttpGet]
        public HttpResponseMessage getAllProductsDetails()
        {
            string query = @"select p.product_id as product_id, p.product_name as product_name, u.unit_name as unit_name, i.product_quantity as product_quantity, p.purchase_price as purchase_price, p.sell_price as sell_price, p.product_limit as product_limit, p.taxes as taxes, g.group_name as group_name from dbo.products p, dbo.inventory_items i, dbo.units u, dbo.groups g where p.product_id=i.product_id and u.unit_id=p.unit_id and g.group_id=p.group_id";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


    }
}
