﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class ExpensesController : ApiController
    {
        //add expenses types
        public string Post(expenses ex)
        {
            try
            {
                string query = @"insert into dbo.expenses_types(exp_id, exp_name) values(N'" + ex.exp_id + "',N'" + ex.exp_name + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //delete units
        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.expenses_types where exp_id='" + id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //retrive all expenses types
        [Route("api/Expenses/getAllExpensesTypes")]
        [HttpGet]
        public HttpResponseMessage getAllExpensesTypes()
        {
            string query = @"select * from dbo.expenses_types";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // GetExpensesTypesLastID
        [Route("api/Expenses/GetExpensesTypesLastID")]
        [HttpGet]
        public HttpResponseMessage GetExpensesTypesLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.expenses_types')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        //insert expenses details
        [Route("api/Expenses/insertExpensesDetails")]
        [HttpPost]
        public string insertExpensesDetails(expensesDetails ed)
        {
            try
            {
                string query = @"insert into dbo.expenses(exp_id, amount, treasury_id, exp_date, notes) values(N'" + ed.exp_id + "',N'" + ed.amount + "',N'" + ed.treasury_id + "',N'" + ed.exp_date +"',N'"+ ed.notes +"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        //GetExpensesDetailsLastID
        [Route("api/Expenses/GetExpensesDetailsLastID")]
        [HttpGet]
        public HttpResponseMessage GetExpensesDetailsLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.expenses')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        //retrive total Expenses
        [Route("api/Expenses/getTotalExpenses")]
        [HttpPost]
        public HttpResponseMessage getTotalExpenses(expensesSearch eS)
        {
            string query = @"select e.amount, e.exp_date, e.notes, t.exp_name from dbo.expenses e, dbo.expenses_types t where e.exp_id=t.exp_id and e.exp_date between N'" + eS.exp_from + "' and N'" + eS.exp_to + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        //retrive total amount Expenses
        [Route("api/Expenses/getTotalAmountExpenses")]
        [HttpPost]
        public HttpResponseMessage getTotalAmountExpenses(expensesSearch eS)
        {
            string query = @"select SUM(e.amount) as total from dbo.expenses e, dbo.expenses_types t where e.exp_id=t.exp_id and e.exp_date between N'" + eS.exp_from + "' and N'" + eS.exp_to + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
