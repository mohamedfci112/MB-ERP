﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WepAPI.Models;

namespace WepAPI.Controllers
{
    public class InventoryController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string query = @"select * from dbo.inventory";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
               da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string Post(Inventory inv)
        {
            try
            {
                string query = @"insert into dbo.inventory(invent_id, invent_name, notes) values(N'" + inv.invent_id + "',N'" + inv.invent_name + "',N'" + inv.notes + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfuly";
            }
            catch(Exception)
            {
                return "Faild";
            }
        }

        public string Put(Inventory inv)
        {
            try
            {
                string query = @"update dbo.inventory set invent_name=N'"+inv.invent_name+"', notes=N'"+inv.notes+"' where invent_id='"+inv.invent_id+"'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        public string Delete(int id)
        {
            try
            {
                string query = @"delete from dbo.inventory where invent_id='" + id +"'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfuly";
            }
            catch (Exception)
            {
                return "Faild";
            }
        }

        [Route("api/Inventory/GetAllInventoriesSearch")]
        [HttpPost]
        public HttpResponseMessage GetAllInventoriesSearch(Inventory inv)
        {
            string v = inv.invent_name;
            string query = @"select * from dbo.inventory where invent_name like N'%" + inv.invent_name + "%'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Inventory/GetInventoriesSearch")]
        [HttpPost]
        public HttpResponseMessage GetInventoriesSearch(Inventory inv)
        {
            string v = inv.invent_name;
            string query = @"select * from dbo.inventory where invent_id = '" + inv.invent_id + "'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Inventory/GetAllLastID")]
        [HttpGet]
        public HttpResponseMessage GetAllLastID()
        {
            string query = @"select IDENT_CURRENT('dbo.inventory')";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Inventory/AddInventoryItems")]
        [HttpPost]
        public HttpResponseMessage AddInventoryItems(inventoryItems inv)
        {
            try
            {
                string query = @"insert into dbo.inventory_items(product_id, invent_id, product_quantity, purchase_price, sell_price) values(N'" + inv.product_id + "',N'" + inv.invent_id + "',N'" + inv.product_quantity + "',N'" + inv.purchase_price + "',N'" + inv.sell_price + @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }


        // get with inventory
        [Route("api/Inventory/GardOneInventory")]
        [HttpPost]
        public HttpResponseMessage GardOneInventory(inventoryItems inv)
        {
            string query = @"select ii.id, p.product_name, i.invent_name, ii.product_quantity, ii.purchase_price, ii.sell_price from dbo.products p, dbo.inventory_items ii, dbo.inventory i where p.product_id = ii.product_id and i.invent_id=ii.invent_id and ii.invent_id='"+inv.invent_id+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        // get with all inventory
        [Route("api/Inventory/GardInventory")]
        [HttpGet]
        public HttpResponseMessage GardInventory(inventoryItems inv)
        {
            string query = @"select ii.id, p.product_name, i.invent_name, ii.product_quantity, ii.purchase_price, ii.sell_price from dbo.products p, dbo.inventory_items ii, dbo.inventory i where p.product_id = ii.product_id and i.invent_id=ii.invent_id";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        //retrive total balance in inventory
        [Route("api/Inventory/getTotalBalanceInventory")]
        [HttpPost]
        public HttpResponseMessage getTotalBalanceInventory(inventoryItems i)
        {
            string query = @"select SUM(CAST(product_quantity AS float)) as total from dbo.inventory_items where invent_id='" + i.invent_id + "' and product_id='" + i.product_id + @"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Inventory/TransferInventoryItems")]
        [HttpPost]
        public HttpResponseMessage TransferInventoryItems(inventoryTransfers it)
        {
            try
            {
                string query = @"insert into dbo.inventory_transfers(product_id, invent_from_id, invent_to_id, product_quantity, purchase_price, sell_price, trans_date, trans_admin, trans_reason) values(N'" + it.product_id + "',N'" + it.invent_from_id + "',N'" + it.invent_to_id + "',N'" + it.product_quantity + "',N'" + it.purchase_price + "',N'"+it.sell_price+"',N'"+it.trans_date+"',N'"+it.trans_admin+"',N'"+it.trans_reason+ @"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/EditInventoryQuantity")]
        [HttpPut]
        public HttpResponseMessage EditInventoryQuantity(inventoryItems i)
        {
            try
            {
                string query = @"if not exists(select invent_id,product_id from dbo.inventory_items where invent_id='" + i.invent_id + "' and product_id='"+i.product_id+"') Begin insert into dbo.inventory_items(product_id, invent_id, product_quantity, purchase_price, sell_price) values(N'" + i.product_id + "',N'" + i.invent_id + "',N'" + i.product_quantity + "',N'" + i.purchase_price + "',N'" + i.sell_price + "') End else begin update dbo.inventory_items set product_quantity=N'" + i.product_quantity + "' where invent_id='" + i.invent_id + "' and product_id='" + i.product_id + "' end";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/InventoryTransfersReport")]
        [HttpPost]
        public HttpResponseMessage InventoryTransfersReport(inventoryTransfers inv)
        {
            try
            {
                string query = @"select p.product_name, i.invent_name as Fro, it.product_quantity, it.purchase_price, it.sell_price, it.trans_date, it.trans_admin, it.trans_reason from dbo.inventory_transfers it, dbo.products p, inventory i where p.product_id=it.product_id and it.invent_from_id=i.invent_id and it.trans_date between '"+inv.date1+"' and '"+inv.date2+"' order by p.product_name, it.trans_date";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/InventoryTransfersReport1")]
        [HttpPost]
        public HttpResponseMessage InventoryTransfersReport1(inventoryTransfers inv)
        {
            try
            {
                string query = @"select p.product_name, i.invent_name as Too from dbo.inventory_transfers it, dbo.products p, inventory i where p.product_id=it.product_id and it.invent_to_id=i.invent_id and it.trans_date between '"+inv.date1+"' and '"+inv.date2+"' order by p.product_name, it.trans_date";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        // get with specific inventory
        [Route("api/Inventory/WithInventoryTransfersReport")]
        [HttpPost]
        public HttpResponseMessage WithInventoryTransfersReport(inventoryTransfers inv)
        {
            try
            {
                string query = @"select p.product_name, i.invent_name as Fro, it.product_quantity, it.purchase_price, it.sell_price, it.trans_date, it.trans_admin, it.trans_reason from dbo.inventory_transfers it, dbo.products p, inventory i where p.product_id=it.product_id and it.invent_from_id=i.invent_id and it.invent_from_id='" + inv.invent_from_id + "' and it.invent_to_id='"+inv.invent_to_id+"' and it.trans_date between '" + inv.date1 + "' and '" + inv.date2 + "' order by p.product_name, it.trans_date";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/WithInventoryTransfersReport1")]
        [HttpPost]
        public HttpResponseMessage WithInventoryTransfersReport1(inventoryTransfers inv)
        {
            try
            {
                string query = @"select p.product_name, i.invent_name as Too from dbo.inventory_transfers it, dbo.products p, inventory i where p.product_id=it.product_id and it.invent_to_id=i.invent_id and it.invent_from_id='" + inv.invent_from_id + "' and it.invent_to_id='"+inv.invent_to_id+"' and it.trans_date between '" + inv.date1 + "' and '" + inv.date2 + "' order by p.product_name, it.trans_date";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }


        // get product and inventory search
        [Route("api/Inventory/GetAllProductSearch")]
        [HttpPost]
        public HttpResponseMessage GetAllProductSearch(product p)
        {
            string query = @"select * from dbo.products where product_name like N'%" + p.product_name + "%'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Inventory/GetProductSearch")]
        [HttpPost]
        public HttpResponseMessage GetProductSearch(inventoryItems inv)
        {
            string query = @"select * from dbo.inventory_items where invent_id = '" + inv.invent_id + "' and product_id='"+inv.product_id+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Inventory/updateCostInventory")]
        [HttpPut]
        public HttpResponseMessage updateCostInventory(inventoryItems i)
        {
            try
            {
                string query = @"update dbo.inventory_items set purchase_price='" + i.purchase_price + "', sell_price='" + i.sell_price + "' where product_id='" +i.product_id+ "' and invent_id='"+i.invent_id+"'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/updateQuantityInventory")]
        [HttpPut]
        public HttpResponseMessage updateQuantityInventory(inventoryItems i)
        {
            try
            {
                string query = @"update dbo.inventory_items set product_quantity='" + i.product_quantity + "' where product_id='" + i.product_id + "' and invent_id='" + i.invent_id + "'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/changeQuantityInventory")]
        [HttpPost]
        public HttpResponseMessage changeQuantityInventory(quantityChanges q)
        {
            try
            {
                string query = @"insert into dbo.inventory_edit_quantity(product_id,invent_id,old_product_quantity,new_product_quantity,change_date) values(N'" + q.product_id + "',N'" + q.invent_id + "',N'" + q.old_product_quantity + "',N'" + q.new_product_quantity + "','" + q.change_date + "')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/changeCostInventory")]
        [HttpPost]
        public HttpResponseMessage changeCostInventory(costChanges c)
        {
            try
            {
                string query = @"insert into dbo.inventory_edit_cost(product_id,invent_id,old_purchase_price,new_purchase_price,old_sell_price,new_sell_price,change_date) values(N'" + c.product_id + "',N'" + c.invent_id + "',N'" + c.old_purchase_price + "',N'" + c.new_purchase_price + "',N'" + c.old_sell_price + "',N'" + c.new_sell_price + "','" + c.change_date + "')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        // insert talf
        [Route("api/Inventory/addInventoryTalf")]
        [HttpPost]
        public HttpResponseMessage addInventoryTalf(inventoryTalf i)
        {
            try
            {
                string query = @"insert into dbo.inventory_talf(product_id,product_talf_quantity,talf_date,talf_admin,talf_reason,invent_id) values(N'"+i.product_id+"',N'"+i.product_talf_quantity+"',N'"+i.talf_date+"',N'"+i.talf_admin+"',N'"+i.talf_reason+"',N'"+i.invent_id+"')";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }


        [Route("api/Inventory/GetTalfReport")]
        [HttpPost]
        public HttpResponseMessage GetTalfReport(inventoryTalf inv)
        {
            string query = @"select it.id, p.product_name, i.invent_name, it.product_talf_quantity, it.talf_date, it.talf_admin, it.talf_reason from dbo.inventory_talf it, dbo.products p, dbo.inventory i where it.product_id=p.product_id and it.invent_id=i.invent_id and it.invent_id='"+inv.invent_id+"' and talf_date between '"+inv.fromDate+"' and '"+inv.toDate+"'";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Inventory/EditInventoryQuantityPurchase")]
        [HttpPut]
        public HttpResponseMessage EditInventoryQuantityPurchase(inventoryItems i)
        {
            try
            {
                string query = @"if not exists(select invent_id,product_id from dbo.inventory_items where invent_id='" + i.invent_id + "' and product_id='" + i.product_id + "') Begin insert into dbo.inventory_items(product_id, invent_id, product_quantity, purchase_price, sell_price) values(N'" + i.product_id + "',N'" + i.invent_id + "',N'" + i.product_quantity + "',N'" + i.purchase_price + "',N'" + i.sell_price + "') End else begin update dbo.inventory_items set product_quantity = (select product_quantity from dbo.inventory_items where product_id='" + i.product_id + "' and invent_id='" + i.invent_id + "') + CAST('" + i.product_quantity + "' AS float) where product_id='" + i.product_id + "' and invent_id='" + i.invent_id + "' end";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/EditInventoryQuantityReturnedPurchase")]
        [HttpPut]
        public HttpResponseMessage EditInventoryQuantityReturnedPurchase(inventoryItems i)
        {
            try
            {
                string query = @"update dbo.inventory_items set product_quantity = (select product_quantity from dbo.inventory_items where product_id='"+i.product_id+"' and invent_id='"+i.invent_id+"') - CAST('"+i.product_quantity+"' AS float) where product_id='"+i.product_id+"' and invent_id='"+i.invent_id+"'";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return Request.CreateResponse(HttpStatusCode.OK, table);
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.Forbidden);
            }
        }

        [Route("api/Inventory/GetLastQuantityEdits")]
        [HttpGet]
        public HttpResponseMessage GetLastQuantityEdits()
        {
            string query = @"select top 5 p.product_name, i.invent_name, q.old_product_quantity, q.new_product_quantity, q.change_date from dbo.products p, dbo.inventory i, dbo.inventory_edit_quantity q where p.product_id=q.product_id and i.invent_id=q.invent_id";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Inventory/GetLastCostEdits")]
        [HttpGet]
        public HttpResponseMessage GetLastCostEdits()
        {
            string query = @"select top 5 p.product_name, i.invent_name, c.old_purchase_price, c.old_sell_price, c.new_purchase_price, c.new_sell_price, c.change_date from dbo.products p, dbo.inventory i, dbo.inventory_edit_cost c where p.product_id=c.product_id and i.invent_id=c.invent_id";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["noorDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
